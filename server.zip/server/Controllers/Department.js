// const Department = require('../models/Department');
// const Office = require('../models/Office');

// // Create a new Department
// exports.createDepartment = async (req, res) => {
//   try {
//     const { name, officeName, latitude, longitude } = req.body;

//     // Validate input
//     if (!name || !officeName || !latitude || !longitude) {
//       return res.status(400).json({ message: "Please provide all required fields" });
//     }

//     // Find the office by name
//     const office = await Office.findOne({ name: officeName });

//     if (!office) {
//       return res.status(404).json({ message: "Office not found" });
//     }

//     // Create the new Department
//     const newDepartment = new Department({
//       name,
//       office: office._id,
//       latitude,
//       longitude,
//     });

//     // Save the department to the database
//     const savedDepartment = await newDepartment.save();

//     // Add department to the office's departments array
//     office.departments.push(savedDepartment._id);
//     await office.save();

//     res.status(201).json(savedDepartment);
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };

// // Get all Departments for a specific Office
// exports.getDepartmentsByOffice = async (req, res) => {
//   try {
//     const { officeName } = req.params;

//     // Find the office by name
//     const office = await Office.findOne({ name: officeName }).populate('departments');

//     if (!office) {
//       return res.status(404).json({ message: "Office not found" });
//     }

//     res.status(200).json(office.departments);
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };



// const Department = require('../models/Department');
// const Office = require('../models/Office');

// // Create a new Department
// exports.createDepartment = async (req, res) => {
//   try {
//     const { name, officeName, latitude, longitude } = req.body;

//     // Validate input
//     if (!name || !officeName || !latitude || !longitude) {
//       return res.status(400).json({ message: "Please provide all required fields" });
//     }

//     // Find the office by name
//     const office = await Office.findOne({ name: officeName });

//     if (!office) {
//       return res.status(404).json({ message: "Office not found" });
//     }

//     // Create the new Department
//     const newDepartment = new Department({
//       name,
//       office: office._id,
//       latitude,
//       longitude,
//     });

//     // Save the department to the database
//     const savedDepartment = await newDepartment.save();

//     // Add department to the office's departments array
//     office.departments.push(savedDepartment._id);
//     await office.save();

//     res.status(201).json({ success: true, department: savedDepartment });
//   } catch (error) {
//     console.error('Error creating department:', error.message);
//     res.status(500).json({ success: false, message: "Server error. Please try again later." });
//   }
// };

// // Get all Departments for a specific Office
// exports.getDepartmentsByOffice = async (req, res) => {
//   try {
//     const { officeName } = req.params;

//     // Find the office by name and populate departments
//     const office = await Office.findOne({ name: officeName }).populate('departments');

//     if (!office) {
//       return res.status(404).json({ message: "Office not found" });
//     }

//     res.status(200).json({ success: true, departments: office.departments });
//   } catch (error) {
//     console.error('Error fetching departments:', error.message);
//     res.status(500).json({ success: false, message: "Server error. Please try again later." });
//   }
// };


const Department = require('../models/Department');
const Office = require('../models/Office');

// Create a new Department
exports.createDepartment = async (req, res) => {
  try {
    const { name, officeName } = req.body;

    // Validate input
    if (!name || !officeName) {
      return res.status(400).json({ success: false, message: "Please provide all required fields" });
    }

    // Find the office by name
    const office = await Office.findOne({ name: officeName });

    if (!office) {
      return res.status(404).json({ success: false, message: "Office not found" });
    }

    // Create the new Department with default values for latitude and longitude
    const newDepartment = new Department({
      name,
      office: office._id,
    });

    // Save the department to the database
    const savedDepartment = await newDepartment.save();

    // Add department to the office's departments array
    office.departments.push(savedDepartment._id);
    await office.save();

    res.status(201).json({ success: true, department: savedDepartment });
  } catch (error) {
    console.error('Error creating department:', error.message);
    res.status(500).json({ success: false, message: "Server error. Please try again later." });
  }
};

// Get all Departments for a specific Office
exports.getDepartmentsByOffice = async (req, res) => {
  try {
    const { officeName } = req.params;

    // Find the office by name and populate departments
    const office = await Office.findOne({ name: officeName }).populate('departments');

    if (!office) {
      return res.status(404).json({ success: false, message: "Office not found" });
    }

    res.status(200).json({ success: true, departments: office.departments });
  } catch (error) {
    console.error('Error fetching departments:', error.message);
    res.status(500).json({ success: false, message: "Server error. Please try again later." });
  }
};
