const express = require('express');
const app = express();

// Middleware to parse JSON bodies
app.use(express.json());

const mongoose = require('mongoose');

// // Connect to MongoDB
mongoose.connect("mongodb+srv://johnkhore26:RoOrWmTmyzRB1LlN@cluster0.n4dgy.mongodb.net/", {
    useNewUrlParser: true, 
    useUnifiedTopology: true
})
.then(() => {
    console.log("Connection Successful");
})
.catch((error) => {
    console.error("Error connecting to MongoDB:", error);
});

//route import and mount
const user = require("./routes/user");
const checkinRoutes = require('./routes/checkin')
const recentdataRoutes = require('./routes/LiveStats')
const department = require('./routes/Department')
const office = require('./routes/Office');
// const Location = require('./routes/Office')


//livestat
app.use("/api/v1/admin",recentdataRoutes);


// 
app.use(`/api/v1`, user);
app.use('/api/checkins', checkinRoutes);
app.use('/api/department', department);
app.use('/api/office', office);
// app.use('/api/Location', Location);


app.listen(3000, ()=>{
    console.log("Server is running on port : 3000");
})






