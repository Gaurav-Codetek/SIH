const express = require('express');
const router = express.Router();

const {createDepartment,getDepartmentsByOffice} = require('../Controllers/Department');

router.post('/createDepartment', createDepartment);
// http://192.168.18.208:3000/api/department/getDepartmentsByOffice/Chandigarh
router.get('/getDepartmentsByOffice/:officeName', getDepartmentsByOffice);


module.exports = router;