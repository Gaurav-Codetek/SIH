const mongoose = require('mongoose');

// i am writing here lets see if its working finely
// here we have to make a
const OfficeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please enter the office name"],
    unique: true,
  },
  latitude: {
    type: Number,
    required: [true, "Please enter the latitude"],
  },
  longitude: {
    type: Number,
    required: [true, "Please enter the longitude"],
  },
  departments: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Department',
  }],
  employees: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  }]

  //now move to controlle
}, {
  timestamps: true,
});

const Office = mongoose.model('Office', OfficeSchema);

module.exports = Office;
